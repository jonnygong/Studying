$('.dropdown').tendina({
    animate: true,
    speed: 500,
    openCallback: function($clickedEl) {
        console.log($clickedEl);
    },
    closeCallback: function($clickedEl) {
        console.log($clickedEl);
    }
})

$(function() {
    var sliarrn = [15, 17, 16, 18]
        var $thead = $('#thead'),
            $tbody = $('#tbody'),
            $button = $('#stu-past-button-past'),
            $button2 = $('#button-signed'),
            wk = true,
            slidate = new Date(),
            _nullnei = '',
            de = slidate.getDate() + 1;
        var monthFirst = new Date(slidate.getFullYear(), parseInt(slidate.getMonth()), 1).getDay();
        var d = new Date(slidate.getFullYear(), parseInt(slidate.getMonth() + 1), 0);
        var conter = d.getDate();

        for (var i = 1; i <= 5; i++) {
            _nullnei += "<tr>";
            for (var j = 1; j <= 7; j++) {
                _nullnei += '<td></td>';
            }
            _nullnei += "</tr>";
        }
        $tbody.html(_nullnei);

        var $slitd = $tbody.find("td");
        for (var i = 0; i < conter; i++) {
            $slitd.eq(i + monthFirst).html("<p>" + parseInt(i + 1) + "</p>")
        }

        Funback();
        Funmore();
        Funmonth();
        $button.on("click", function() {
            if (wk == true) {
                sliarrn.push(de - 1);
                Funmonth();
                alert('已签到');
            }
        })
        $button2.on("click", function() {
            alert('你本月已签到' + sliarrn.length + '次')
        })
        function Funback() {
            $slitd.eq(parseInt(de)).addClass('color')
        }

        function Funmore() {
            for (var i = 0; i < de; i++) {
                $slitd.eq(i).addClass('weiqian')
            }
        }
        function Funmonth() {
            for (var i = 0; i < conter; i++) {
                for (var j = 0; j < sliarrn.length; j++) {
                    if (i == sliarrn[j]) {
                        $slitd.eq(i + 1).addClass('los')
                    }
                }
            }
        }
    })
