﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class _Index : System.Web.UI.Page
{
    public string rankList = "";
    public string latestList = "";

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)//确认是第一次访问
        {
            int len = GridView1.Rows.Count; // 获取条数

            for (int i = 0; i < len; i++)
            {
                string softName = GridView1.Rows[i].Cells[1].Text.Trim(); // 获取软件名
                string softUrl = GridView1.Rows[i].Cells[2].Text.Trim(); // 获取下载地址
                rankList += "<li><a href=\"" + softUrl + "\">" + softName + "</a><strong style=\"float:right;margin-right:20px;\">&gt;</strong></li>";
            }
            int count = GridView2.Rows.Count; // 获取条数
            for (int i = 0; i < count; i++)
            {
                string softName = GridView2.Rows[i].Cells[2].Text.Trim(); // 获取软件名
                string softUrl = GridView2.Rows[i].Cells[1].Text.Trim(); // 获取下载地址
                string softImg = GridView2.Rows[i].Cells[0].Text.Trim();
                string addDate = GridView2.Rows[i].Cells[4].Text.Trim();
                latestList += "<div class=\"left icon\"><img src=\"" + softImg + "\" width=\"100\" height=\"91\" alt=\"\"/> <div class=\"size2\">" + softName + "</div></div>";
            }


        }
    }

}
