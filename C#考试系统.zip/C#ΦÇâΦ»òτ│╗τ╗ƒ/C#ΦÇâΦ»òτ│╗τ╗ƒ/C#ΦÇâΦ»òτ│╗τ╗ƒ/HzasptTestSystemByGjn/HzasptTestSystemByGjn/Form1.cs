﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
using System.IO;
using System.Net.Sockets;
using System.Threading;
using System.Net;

namespace HzasptTestSystemByGjn
{
    public partial class Form1 : Form
    {

        string importfilename;
        string connstr = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=\"" + System.Environment.CurrentDirectory + "\\serverdb.mdb\"";


        //网络组件
        private TcpListener tl;
        private NetworkStream ns;


        public Form1()
        {
            InitializeComponent();
        }
        
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                label1.Text = "您选择的名单是：" + openFileDialog1.FileName + "，请单击“导入名单”进行导入。";
                importfilename = openFileDialog1.FileName;
                button2.Visible = true;
            }


        }

        private void button2_Click(object sender, EventArgs e)
        {
            //导入excel
            DataSet OleDsExcle = new DataSet();
            try
            {
                string strConn;
                strConn = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + importfilename + ";Extended Properties='Excel 8.0;HDR=False;IMEX=1'";
                OleDbConnection OleConn = new OleDbConnection(strConn);
                OleConn.Open();
                String sql = "SELECT * FROM  [Sheet1$]";//可更改Sheet名称，比如sheet2，等等    

                OleDbDataAdapter OleDaExcel = new OleDbDataAdapter(sql, OleConn);

                OleDaExcel.Fill(OleDsExcle, "Sheet1");
                OleConn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("名单导入失败，请检查EXCEL文件格式！");
            }

            //写入数据库
            try
            {
                OleDbConnection con = new OleDbConnection();
                con.ConnectionString = connstr;
                con.Open();

                OleDbCommand cmd = new OleDbCommand();
                cmd.Connection = con;
                for (int i = 0; i < OleDsExcle.Tables[0].Rows.Count; i++)
                {
                    OleDbDataAdapter da = new OleDbDataAdapter("select * from main_Test where sno='" + OleDsExcle.Tables[0].Rows[i][0].ToString() + "' and sname='" + OleDsExcle.Tables[0].Rows[i][1].ToString() + "'", con);
                    DataSet dgv = new DataSet();
                    da.Fill(dgv);

                    int gets = dgv.Tables[0].Rows.Count;

                    if (gets == 0)
                    {
                        cmd.CommandText = "insert into main_Test(sno,sname) values('" + OleDsExcle.Tables[0].Rows[i][0].ToString() + "','" + OleDsExcle.Tables[0].Rows[i][1].ToString() + "')";
                        cmd.ExecuteNonQuery();
                    }
                }
                MessageBox.Show("导入成功！");
            }
            catch (Exception ex)
            {
                MessageBox.Show("导入数据库失败，请检查access文件");
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            
        }

        //启动服务
        private void startService()
        {
            //开启8888端口的监听
            tl = new TcpListener(2324);
            tl.Start();

            //开启线程
            Thread th = new Thread(new ThreadStart(listen));
            th.IsBackground = true;
            th.Start();


        }

        //停止服务
        private void stopService()
        {
            tl.Stop();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SaveFileDialog dlg = new SaveFileDialog();
            dlg.Filter = "Execl files (*.xls)|*.xls";
            dlg.CheckFileExists = false;
            dlg.CheckPathExists = false;
            dlg.FilterIndex = 0;
            dlg.RestoreDirectory = true;
            dlg.CreatePrompt = true;
            dlg.Title = "保存为Excel文件";

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                OleDbConnection con = new OleDbConnection();
                con.ConnectionString = connstr;
                con.Open();
                OleDbDataAdapter da = new OleDbDataAdapter("select * from main_Test", con);
                DataSet dgv = new DataSet();
                da.Fill(dgv);
                Stream myStream;
                myStream = dlg.OpenFile();
                StreamWriter sw = new StreamWriter(myStream, System.Text.Encoding.GetEncoding(-0));
                string columnTitle = "";
                try
                {
                    //写入列标题   
                    sw.WriteLine("学号\t姓名\t成绩");

                    //写入列内容   
                    for (int j = 0; j < dgv.Tables[0].Rows.Count; j++)
                    {
                        string columnValue = "";
                        for (int k = 1; k < 4; k++)
                        {
                            if (k > 1)
                            {
                                columnValue += "\t";
                            }
                            if (dgv.Tables[0].Rows[j][k] == null)
                                columnValue += "";
                            else
                                columnValue += dgv.Tables[0].Rows[j][k].ToString().Trim();
                        }
                        sw.WriteLine(columnValue);
                    }
                    sw.Close();
                    myStream.Close();
                    MessageBox.Show("导出成绩成功。");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(e.ToString());
                }
                finally
                {
                    sw.Close();
                    myStream.Close();
                }
                con.Close();
            }
        }

        private void listen()
        {
            while (true)
            {
                try
                {

                    //获得响应的Socket
                    Socket sock = tl.AcceptSocket();
                    System.Net.IPAddress ipadd;
                    ipadd = (sock.RemoteEndPoint as IPEndPoint).Address;
                    string ip = ipadd.ToString();

                    //通过该Socket实例化网络流           
                    ns = new NetworkStream(sock);

                    //ClientTcp是添加的类，下面会做说明
                    ClientTcp ct = new ClientTcp(ns, ip, connstr);

                    //ct_MyEvent方法注册ClientTcp类的MyEvent事件
                    ct.MyEvent += new MyDelegate(ct_MyEvent);

                    //开启线程
                    Thread th = new Thread(new ThreadStart(ct.TcpThread));
                    th.IsBackground = true;
                    th.Start();
                }
                catch (Exception ex)
                {
                }
            }
        }

        void ct_MyEvent(string temp)
        {

            //响应处理

            OleDbConnection con = new OleDbConnection();
            con.ConnectionString = connstr;
            con.Open();

            OleDbCommand cmd = new OleDbCommand();
            cmd.Connection = con;

            string[] s = temp.Split('|');

            //第一个字符为0表示登录，协议如下 0|学号|姓名|IP
            if (s[0] == "0")
            {
                cmd.CommandText = "update main_Test set sip='" + s[3] + "',sstatus='考试中',starttime='" + DateTime.Now.ToString() + "' where sno='" + s[1] + "'";
            }
            //1表示交成绩，协议如下 1|学号|姓名|成绩|IP
            if (s[0] == "1")
            {
                cmd.CommandText = "update main_Test set score=" + s[3] + ",sstatus='交卷成功',endtime='" + DateTime.Now.ToString() + "' where sno='" + s[1] + "'";
            }
            cmd.ExecuteNonQuery();
            con.Close();
            //refresh_datagrid();
        }

        private void refresh_datagrid()
        {
            OleDbConnection con = new OleDbConnection();
            con.ConnectionString = connstr;
            con.Open();
            OleDbDataAdapter da = new OleDbDataAdapter("select sno as 学号,sname as 姓名,sstatus as 状态,sip as IP地址,starttime as 登录时间 from main_Test order by sstatus", con);
            DataSet dgv = new DataSet();
            da.Fill(dgv);
            dataGridView1.DataSource = dgv.Tables[0];
            con.Close();
        }


        public delegate void MyDelegate(string temp);
        class ClientTcp
        {

            //设置网络流局部对象
            private NetworkStream ns;
            private string cip;
            private string connstr;

            //声明类型为MyDelegate的事件MyEvent
            public event MyDelegate MyEvent;

            //构造函数中接收参数以初始化
            public ClientTcp(NetworkStream ns, string ip, string constr)
            {
                this.ns = ns;
                this.cip = ip;
                this.connstr = constr;
            }

            //服务器端线程所调用的方法
            public void TcpThread()
            {

                //获得相关的封装流
                StreamReader sr = new StreamReader(ns);
                string temp = sr.ReadLine();

                //接收到客户端消息后触发事件将消息回传
                MyEvent(temp + "|" + cip);
                StreamWriter sw = new StreamWriter(ns);

                //检查登录并发送消息给客户端,1为登录成功，0为登录失败
                string[] s = temp.Split('|');
                OleDbConnection con = new OleDbConnection();

                con.ConnectionString = connstr;
                con.Open();
                OleDbDataAdapter da = new OleDbDataAdapter("select * from main_Test where sno='" + s[1] + "' and sname='" + s[2] + "'", con);
                DataSet dgv = new DataSet();
                da.Fill(dgv);

                if (dgv.Tables[0].Rows.Count >= 1)
                {
                    sw.WriteLine("1");
                }
                else
                {
                    sw.WriteLine("0");
                }

                con.Close();
                sw.Flush();
                sw.Close();
                sr.Close();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            refresh_datagrid();
        }

        private void btnStart_Click_1(object sender, EventArgs e)
        {
            if (btnStart.Text == "启动服务")
            {
                btnStart.Text = "停止服务";
                startService();
            }
            else
            {
                btnStart.Text = "启动服务";
                stopService();
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}