using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Net.Sockets;
using System.IO;
using System.IO.Compression;
using Microsoft.CSharp;
using System.Diagnostics;

namespace HzasptTest
{
    public partial class Form2 : Form
    {

        public string sno, sname;//ѧ�š�����
        private string ipaddress;
        string connstr = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=\"" + System.Environment.CurrentDirectory + "\\db.mdb\"; Jet OLEDB:Database Password=mypass";

        int c_question_total, c_question_value, c_current_number, score = 0;
        int isSaved = 0;//�����־
        int times = 3600;
        int timestotal = 5400;

        DataSet ds_cquestion; //�����õ����е�ѡ����
        int[] c_answer; //����ѡ����𰸵�����

        //����������
        private TcpClient tc;
        private NetworkStream ns;

        public Form2()
        {
            InitializeComponent();
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            if (times > 0)
            {
                c_answer[c_current_number] = 3;
            }
            else
            {
                MessageBox.Show("������Ĵ���ʱ���ѹ���");
            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (times > 0)
            {
                c_answer[c_current_number] = 2;
            }
            else
            {
                MessageBox.Show("������Ĵ���ʱ���ѹ���");
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            //����ѧ�š���������ʾ
            label2.Text = sno;
            label4.Text = sname;
            label5.Text = "�����ļ���ΪC:\\" + sno + sname;
            ipaddress = loadIP();

            //��ʾ������֪���
            showPanel(panel1, 0);

            //�ж��Ƿ��ؿ�
            //���ؿ������ʼ����Ŀ
            initQuestion();
            initOp();

            //�ؿ��ģ������ղŵ���Ŀ

            //��ʾѡ����
            displayChoise(c_current_number);
            timer1.Enabled = true;
            timer2.Enabled = true;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (times >= 1)
            {
                times--;
                int t = times / 60;
                if (t > 0)
                {
                    label16.Text = t.ToString() + "����";
                }
                else
                {
                    label16.Text = times.ToString() + "��";
                    if (times % 30 == 0 && times > 0)
                    {
                        MessageBox.Show("���������ʱ�����Ͼ�Ҫ���ˡ�");
                    }
                    else if (times % 30 == 0)
                    {
                        MessageBox.Show("������Ĵ���ʱ�䳬ʱ��");
                    }
                }
            }
            else
            {
                timer1.Enabled = false;
                radioButton1.Enabled = false;
                radioButton2.Enabled = false;
                radioButton3.Enabled = false;
                radioButton4.Enabled = false;
            }
        }

        private int uploadResult()
        {
            string str = "0";
            try
            {
                //ע�᱾��8888�˿�
                tc = new TcpClient(ipaddress, 2324);

                //ʵ��������������
                ns = tc.GetStream();
                //string temp = this.textBox1.Text;

                StreamWriter sw = new StreamWriter(ns);
                StreamReader sr = new StreamReader(ns);

                //��TextBox1��ֵ������������
                string temp = "1|" + sno.ToString() + "|" + sname.ToString() + "|" + score.ToString(); ;
                sw.WriteLine(temp);
                sw.Flush();

                //���շ������˻ش����ַ���
                str = sr.ReadLine();

                sr.Close();
                sw.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("��������ʧ��.");
            }

            //�����ص���1,��ʾ��¼�ɹ�
            if (str == "1")
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }

        private string loadIP()
        {
            string tempstr;
            try
            {
                StreamReader sr = File.OpenText(@"c:\ipconfig.ini");
                tempstr = sr.ReadLine();
            }
            catch (Exception ex)
            {
                MessageBox.Show("û���ҵ�IP�����ļ����뽫��ȷ�������ļ�����C�̸�Ŀ¼");
                tempstr = "192.168.0.1";
            }
            return tempstr;
        }

        public void CompressFile(string sF, string dF)
        {
            if (File.Exists(sF) == false)
            {
                throw new FileNotFoundException();
            }

            byte[] buffer = null;

            try
            {
                using (FileStream sourceS = new FileStream(sF, FileMode.Open, FileAccess.Read, FileShare.Read))
                {
                    buffer = new byte[sourceS.Length];

                    int checkCounter = sourceS.Read(buffer, 0, buffer.Length);

                    using (FileStream desS = new FileStream(dF, FileMode.OpenOrCreate, FileAccess.Write))
                    {
                        using (GZipStream comS = new GZipStream(desS, CompressionMode.Compress, true))
                        {
                            comS.Write(buffer, 0, buffer.Length);
                        }
                    }
                }
            }
            catch (ApplicationException ex)
            {
                MessageBox.Show("ѹ������");
            }
        }

        private void DecompressFile(string sF, string dF)
        {
            if (File.Exists(sF) == false)
            {
                throw new FileNotFoundException();
            }

            byte[] buffer = null;

            try
            {
                using (FileStream sourceS = new FileStream(sF, FileMode.Open))
                {
                    using (GZipStream comS = new GZipStream(sourceS, CompressionMode.Decompress, true))
                    {
                        buffer = new byte[5];
                        int pos = (int)(sourceS.Length - 4);
                        sourceS.Position = pos;
                        sourceS.Read(buffer, 0, 4);
                        sourceS.Position = 0;
                        int checkLength = BitConverter.ToInt32(buffer, 0);

                        byte[] buffer2 = new byte[checkLength + 100];
                        int offset = 0;
                        int total = 0;

                        while (true)
                        {
                            int byteread = comS.Read(buffer2, offset, 100);
                            if (byteread == 0)
                            {
                                break;
                            }

                            offset += byteread;
                            total += byteread;
                        }



                        using (FileStream desS = new FileStream(dF, FileMode.Create))
                        {

                            desS.Write(buffer2, 0, total);

                        }
                    }
                }
            }
            catch (ApplicationException ex)
            {
                MessageBox.Show("��ѹ������");
            }
        }


        private void timer2_Tick(object sender, EventArgs e)
        {
            if (timestotal >= 1)
            {
                timestotal--;
                int t = timestotal / 60;
                if (t > 0)
                {
                    label6.Text = t.ToString() + "����";
                }
                else
                {
                    label6.Text = timestotal.ToString() + "��";
                    if (timestotal % 30 == 0 && timestotal > 0)
                    {
                        MessageBox.Show("����ʱ�����Ͼ�Ҫ���ˣ���ץ����");
                    }
                    else if (times % 30 == 0)
                    {
                        MessageBox.Show("����ʱ���ѹ���ѡ���⽫�Զ��ύ�����ֶ��ύ�����⡣");
                    }
                }
            }
            else
            {
                timer2.Enabled = false;
                saveResult();

                submitResult();
                MessageBox.Show("������ύ�������������������");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            c_current_number = 0;
            displayChoise(c_current_number);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            c_current_number = c_question_total - 1;
            displayChoise(c_current_number);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (c_current_number > 0)
            {
                c_current_number--;
                displayChoise(c_current_number);
            }
            else
            {
                MessageBox.Show("�Ѿ��ǵ�һ���ˣ�");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (c_current_number < c_question_total - 1)
            {
                c_current_number++;
                displayChoise(c_current_number);
            }
            else
            {
                MessageBox.Show("�Ѿ������һ���ˣ�");
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (times > 0)
            {
                c_answer[c_current_number] = 1;
            }
            else
            {
                MessageBox.Show("������Ĵ���ʱ���ѹ���");
            }
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            if (times > 0)
            {
                c_answer[c_current_number] = 4;
            }
            else
            {
                MessageBox.Show("������Ĵ���ʱ���ѹ���");
            }
        }

        //�������ʾ
        private void showPanel(Panel p, int index)
        {
            foreach (Control c in this.Controls)
                if (c is Panel)
                {
                    c.Visible = false;
                }

            p.Visible = true;

            if (index > 0)
            {
                OleDbConnection con = new OleDbConnection();
                con.ConnectionString = connstr;
                con.Open();

                OleDbDataAdapter da;

                switch (index)
                {
                    case 1: da = new OleDbDataAdapter("select * from temp_op where ��Ŀ����='EXCEL'", con); break;
                    case 2: da = new OleDbDataAdapter("select * from temp_op where ��Ŀ����='FP'", con); break;
                    case 3: da = new OleDbDataAdapter("select * from temp_op where ��Ŀ����='PP'", con); break;
                    case 4: da = new OleDbDataAdapter("select * from temp_op where ��Ŀ����='ACCESS'", con); break;
                    default: da = new OleDbDataAdapter("select * from temp_op", con); break;
                }

                DataSet ds = new DataSet();
                da.Fill(ds);

                if (ds.Tables[0].Rows.Count > 0)
                {
                    textBox2.Text = ds.Tables[0].Rows[0][2].ToString();
                }

                Process.Start("explorer", @"c:\" + sno + sname + "\\");

                con.Close();
            }

        }

        //����������
        private void saveResult()
        {
            OleDbConnection con = new OleDbConnection();
            con.ConnectionString = connstr;
            con.Open();

            //��ѧ������������ݿ�
            OleDbCommand cmd = new OleDbCommand();
            cmd.Connection = con;

            for (int i = 0; i < c_question_total; i++)
            {
                cmd.CommandText = "update temp set ѧ����=" + c_answer[i].ToString() + " where ���=" + ds_cquestion.Tables[0].Rows[i]["���"].ToString();
                cmd.ExecuteNonQuery();
            }
            con.Close();
            isSaved = 1;
            MessageBox.Show("����ɹ���");
        }


        //�������ִ���
        private void submitResult()
        {
            int win = 0;

            //����Ƿ񱣴����
            if (isSaved == 1)
            {
                if (MessageBox.Show("ȷ��Ҫ������", " ", MessageBoxButtons.OKCancel) == DialogResult.OK)
                {
                    //�ж϶Դ�
                    OleDbConnection con = new OleDbConnection();
                    con.ConnectionString = connstr;
                    con.Open();


                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "select ��,ѧ���� from temp";
                    OleDbDataReader dr = cmd.ExecuteReader();
                    while (dr.Read())
                    {
                        if (dr.GetInt32(0) == dr.GetInt32(1))
                        {
                            win++;
                        }
                    }
                    dr.Close();

                    //�����ܷ�
                    score = win * c_question_value;

                    //д������
                    OleDbCommand cmd2 = new OleDbCommand();
                    cmd2.Connection = con;
                    cmd2.CommandText = "insert into result(ѧ��,����,�÷�) values('" + sno + "','" + sname + "'," + score.ToString() + ")";
                    cmd2.ExecuteNonQuery();
                    con.Close();

                    //�ϴ����
                    int r = uploadResult();
                    if (r == 0)
                    {
                        MessageBox.Show("����ʧ�ܣ������ԡ�");
                    }
                    else
                    {
                        Application.Exit();
                    }
                }
            }
            else
            {
                MessageBox.Show("���ȱ�������");
            }
        }

        //��ʼ������
        private void initQuestion()
        {
            OleDbConnection con = new OleDbConnection();
            con.ConnectionString = connstr;
            con.Open();

            //���temp��
            OleDbCommand cmd = new OleDbCommand();
            cmd.Connection = con;
            cmd.CommandText = "delete * from temp";
            cmd.ExecuteNonQuery();

            //��ȡ��Ŀ������temp��
            //��ȡ��Ŀ�����ͷ�ֵ
            cmd.CommandText = "select * from config";
            OleDbDataReader dr = cmd.ExecuteReader();
            dr.Read();

            c_question_total = dr.GetInt32(1);
            c_question_value = dr.GetInt32(2);
            c_current_number = 0;

            dr.Close();

            //��ʼ��������
            c_answer = new int[c_question_total];
            for (int z = 0; z < c_question_total; z++)
            {
                c_answer[z] = 0;
            }

            //�����߼���ʼ
            OleDbDataAdapter da = new OleDbDataAdapter("select * from ѡ����", con);

            //��ȡ���е�ѡ����
            DataSet ds = new DataSet();
            da.Fill(ds);

            //��ȡѡ��������
            int total = ds.Tables[0].Rows.Count;

            //��ʼ��������飬���Խ����ķ�ʽ���
            int[] numbers = new int[total];

            for (int i = 0; i < total; i++)
            {
                numbers[i] = i;
            }

            Random rm = new Random();
            for (int j = 0; j < total; j++)
            {

                int x = rm.Next(total);
                int y = rm.Next(total);

                int temp = numbers[x];
                numbers[x] = numbers[y];
                numbers[y] = temp;
            }

            //����ȡ����Ŀ��¼��temp��
            for (int k = 0; k < c_question_total; k++)
            {
                cmd.CommandText = "insert into temp(����,ѡ��һ,ѡ���,ѡ����,ѡ����,��,���) values('" + ds.Tables[0].Rows[numbers[k]][1].ToString() + "','" + ds.Tables[0].Rows[numbers[k]][2].ToString() + "','" + ds.Tables[0].Rows[numbers[k]][3].ToString() + "','" + ds.Tables[0].Rows[numbers[k]][4].ToString() + "','" + ds.Tables[0].Rows[numbers[k]][5].ToString() + "'," + ds.Tables[0].Rows[numbers[k]][6].ToString() + "," + ds.Tables[0].Rows[numbers[k]][0].ToString() + ")";
                cmd.ExecuteNonQuery();
            }

            //��ȡ����ѡ�õ�ѡ����
            OleDbDataAdapter da2 = new OleDbDataAdapter("select * from temp", con);
            ds_cquestion = new DataSet();
            da2.Fill(ds_cquestion);

            con.Close();

        }

        private void initOp()
        {
            OleDbConnection con = new OleDbConnection();
            con.ConnectionString = connstr;
            con.Open();

            //���temp��
            OleDbCommand cmd = new OleDbCommand();
            cmd.Connection = con;
            cmd.CommandText = "delete * from temp_op";
            cmd.ExecuteNonQuery();

            //��������Ŀ¼
            try
            {
                if (!Directory.Exists("c:\\" + sno + sname))
                {
                    Directory.CreateDirectory("c:\\" + sno + sname);
                }
                else
                {

                    Directory.Delete("c:\\" + sno + sname, true);
                    Directory.CreateDirectory("c:\\" + sno + sname);
                }
            }
            catch (Exception ex)
            {
            }

            int index;
            Random rm = new Random();

            //��ȡ���е�Excel��
            OleDbDataAdapter da = new OleDbDataAdapter("select * from ������ where ��Ŀ����='EXCEL'", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            index = rm.Next(0, ds.Tables[0].Rows.Count - 1);
            cmd.CommandText = "insert into temp_op(��Ŀ����,����,�ļ���) values('EXCEL','" + ds.Tables[0].Rows[index][2].ToString() + "','" + ds.Tables[0].Rows[index][3].ToString() + "')";
            cmd.ExecuteNonQuery();
            if (ds.Tables[0].Rows[index][3].ToString() != "N")
            {
                DecompressFile(ds.Tables[0].Rows[index][3].ToString() + ".eat", @"c:\\" + sno + sname + "\\" + ds.Tables[0].Rows[index][3] + ".xls");
                DecompressFile(ds.Tables[0].Rows[index][3].ToString() + ".eat", ds.Tables[0].Rows[index][3] + ".xls");
            }

            //��ȡ���е�Access��
            da = new OleDbDataAdapter("select * from ������ where ��Ŀ����='ACCESS'", con);
            ds = new DataSet();
            da.Fill(ds);
            index = rm.Next(0, ds.Tables[0].Rows.Count - 1);
            cmd.CommandText = "insert into temp_op(��Ŀ����,����,�ļ���) values('ACCESS','" + ds.Tables[0].Rows[index][2].ToString() + "','" + ds.Tables[0].Rows[index][3].ToString() + "')";
            cmd.ExecuteNonQuery();
            if (ds.Tables[0].Rows[index][3].ToString() != "N")
            {
                DecompressFile(ds.Tables[0].Rows[index][3].ToString() + ".aat", @"c:\\" + sno + sname + "\\" + ds.Tables[0].Rows[index][3] + ".mdb");
                DecompressFile(ds.Tables[0].Rows[index][3].ToString() + ".aat", ds.Tables[0].Rows[index][3] + ".mdb");
            }

            //��ȡ���е�PowerPoint��
            da = new OleDbDataAdapter("select * from ������ where ��Ŀ����='PP'", con);
            ds = new DataSet();
            da.Fill(ds);
            index = rm.Next(0, ds.Tables[0].Rows.Count - 1);
            cmd.CommandText = "insert into temp_op(��Ŀ����,����,�ļ���) values('PP','" + ds.Tables[0].Rows[index][2].ToString() + "','" + ds.Tables[0].Rows[index][3].ToString() + "')";
            cmd.ExecuteNonQuery();
            if (ds.Tables[0].Rows[index][3].ToString() != "N")
            {
                DecompressFile(ds.Tables[0].Rows[index][3].ToString() + ".pat", @"c:\\" + sno + sname + "\\" + ds.Tables[0].Rows[index][3] + ".ppt");
                DecompressFile(ds.Tables[0].Rows[index][3].ToString() + ".pat", ds.Tables[0].Rows[index][3] + ".ppt");
            }

            //��ȡ���е�FrontPage��
            da = new OleDbDataAdapter("select * from ������ where ��Ŀ����='FP'", con);
            ds = new DataSet();
            da.Fill(ds);
            index = rm.Next(0, ds.Tables[0].Rows.Count - 1);
            cmd.CommandText = "insert into temp_op(��Ŀ����,����,�ļ���) values('FP','" + ds.Tables[0].Rows[index][2].ToString() + "','" + ds.Tables[0].Rows[index][3].ToString() + "')";
            cmd.ExecuteNonQuery();
            if (ds.Tables[0].Rows[index][3].ToString() != "N")
            {
                string[] fs = ds.Tables[0].Rows[index][3].ToString().Split('|');
                DecompressFile(fs[0] + ".hat", @"c:\\" + sno + sname + "\\" + fs[0] + ".htm");
                DecompressFile(fs[0] + ".hat", fs[0] + ".htm");

                for (int ins = 1; ins < fs.Length; ins++)
                {
                    File.Copy(fs[ins], @"c:\\" + sno + sname + "\\" + fs[ins], true);
                }
            }

            con.Close();



        }

        //��ʾѡ����
        private void displayChoise(int pos)
        {
            textBox1.Text = ds_cquestion.Tables[0].Rows[pos][1].ToString();
            radioButton1.Text = ds_cquestion.Tables[0].Rows[pos][2].ToString();
            radioButton2.Text = ds_cquestion.Tables[0].Rows[pos][3].ToString();
            radioButton3.Text = ds_cquestion.Tables[0].Rows[pos][4].ToString();
            radioButton4.Text = ds_cquestion.Tables[0].Rows[pos][5].ToString();

            if (c_answer[c_current_number] == 0)
            {
                radioButton1.Checked = false;
                radioButton2.Checked = false;
                radioButton3.Checked = false;
                radioButton4.Checked = false;
            }
            else
            {
                switch (c_answer[c_current_number])
                {
                    case 1: radioButton1.Checked = true; break;
                    case 2: radioButton2.Checked = true; break;
                    case 3: radioButton3.Checked = true; break;
                    case 4: radioButton4.Checked = true; break;
                    default: break;
                }
            }

            groupBox2.Text = "��" + (c_current_number + 1).ToString() + "�⣬��" + c_question_total.ToString() + "��";

        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            string choise = treeView1.SelectedNode.Text;

            switch (choise)
            {
                case "������֪": showPanel(panel1, 0); break;
                case "��ѡ��": showPanel(panel2, 0); break;
                
                case "Excel������": showPanel(panel3, 1); break;
                case "FrontPage������": showPanel(panel3, 2); break;
                case "PowerPoint������": showPanel(panel3, 3); break;
                case "Access������": showPanel(panel3, 4); break;
                case "������": saveResult(); break;
                case "��������": submitResult(); break;
                default: break;

            }
        }
    }
}