﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Net.Sockets;
using System.IO;

namespace HzasptTest
{
    public partial class Form1 : Form
    {

        string connstr = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=\"" + System.Environment.CurrentDirectory + "\\db.mdb\"; Jet OLEDB:Database Password=mypass";

        //声明网络流
        private TcpClient tc;
        private NetworkStream ns;
        private string ipaddress;

        public Form1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //验证两次输入的学号是否一样
            if (textBox1.Text != textBox2.Text)
            {
                MessageBox.Show("两次输入的学号不一致，请重新输入！");
            }
            else
            {

                //验证是否已经参加过考试，若参加过，提示重考或者继续考试

                //写入log

                //将学号，姓名传入下一个窗体并打开
                string str = "0";
                try
                {
                    //注册本机8888端口
                    tc = new TcpClient(ipaddress, 2324);

                    //实例化网络流对象
                    ns = tc.GetStream();
                    //string temp = this.textBox1.Text;

                    StreamWriter sw = new StreamWriter(ns);
                    StreamReader sr = new StreamReader(ns);

                    //将TextBox1的值传给服务器端
                    string temp = "0|" + textBox1.Text + "|" + textBox3.Text;
                    sw.WriteLine(temp);
                    sw.Flush();

                    //接收服务器端回传的字符串
                    str = sr.ReadLine();

                    sr.Close();
                    sw.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }

                //若返回的是1,表示登录成功
                if (str == "1")
                {
                    Form2 ft = new Form2();
                    ft.sno = textBox1.Text;
                    ft.sname = textBox3.Text;
                    ft.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("登录失败，请检查学号和姓名。");
                }

            }



        }

        private string loadIP()
        {
            string tempstr;
            try
            {
                StreamReader sr = File.OpenText(@"c:\ipconfig.ini");
                tempstr = sr.ReadLine();
            }
            catch (Exception ex)
            {
                MessageBox.Show("没有找到配置文件，请将正确的配置文件放入C盘根目录");
                tempstr = "192.168.0.1";
            }
            return tempstr;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ipaddress = loadIP();
            
        }
    }
}