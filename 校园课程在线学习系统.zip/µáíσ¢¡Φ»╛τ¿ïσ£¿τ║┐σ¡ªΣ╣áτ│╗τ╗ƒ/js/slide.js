$(function() {
    $('#course-teacher-slider').marquee({
        auto: false,
        speed: 1000,
        showNum: 1,
        stepLen: 1,
        prevElement: $('#prev'),
        nextElement: $('#next')
    });
})
