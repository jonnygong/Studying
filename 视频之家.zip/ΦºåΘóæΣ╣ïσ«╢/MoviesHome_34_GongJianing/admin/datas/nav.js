﻿var navs = [{
	"title": "视频管理",
	"icon": "fa-cubes",
	"spread": true,
	"children": [{
		"title": "添加视频",
		"icon": "&#xe641;",
		"href": "addMovie.aspx"
	}, {
		"title": "视频信息",
		"icon": "&#xe63c;",
		"href": "movieInfo.html"
	}]
}, {
	"title": "类别管理",
	"icon": "fa-check-square-o",
	"spread": false,
	"href":"addTypes.html"
//	"children": [{
//		"title": "添加类别",
//		"icon": "fa-table",
//		"href": "begtable.html"
//	}, {
//		"title": "管理类别",
//		"icon": "fa-navicon",
//		"href": "navbar.html"
//	}]
},{
	"title": "用户管理",
	"icon": "fa-cogs",
	"spread": false,
	"href":"addUser.html"
//	"children": [{
//		"title": "添加用户",
//		"icon": "fa-table",
//		"href": "begtable.html"
//	}, {
//		"title": "管理用户",
//		"icon": "fa-navicon",
//		"href": "navbar.html"
//	}]
}];