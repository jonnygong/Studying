﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Collections;
using System.Security.Cryptography;
using System.Text;
using System.Xml;
using System.Collections.Generic;

public partial class _Default : System.Web.UI.Page 
{
    public static Dictionary<string, GameItem> Store = new Dictionary<string, GameItem>();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.RequestType == "GET")
        {
            verifySignature();
        }
        else {
            WXUserMessage msg = WXUserMessage.GetUserMessageFromRequest(Request);
            GameItem game = Store.ContainsKey(msg.FromUserName) ? Store[msg.FromUserName] : null;
            if (game != null && game.replyMessages.Count > 0 && game.replyMessages.Count<6 && game.isWin==false)
            {
                int result = 0;
                bool isInt = int.TryParse(msg.Content, out result);

                if (isInt) {
                    if (result > game.answer) {
                        game.userMessages.Add(msg.Content);
                        game.replyMessages.Add("大了，再猜！");
                        Store[msg.FromUserName] = game;
                        Response.Write(msg.ResponseWithText("大了，再猜！"));
                    }
                    if (result < game.answer)
                    {
                        game.userMessages.Add(msg.Content);
                        game.replyMessages.Add("小了，再猜！");
                        Store[msg.FromUserName] = game;
                        Response.Write(msg.ResponseWithText("小了，再猜！"));
                    }
                    if (result == game.answer)
                    {
                        game.userMessages.Add(msg.Content);
                        game.replyMessages.Add("天哪，你猜对了！");
                        Store[msg.FromUserName] = game;
                        Response.Write(msg.ResponseWithText("天哪，你猜对了！回复任意文字即可获得奖励！"));
                    }
                }
                else if (msg.Content == "不玩了")
                {
                    Store.Remove(msg.FromUserName);
                    Response.Write(msg.ResponseWithText("您已退出游戏，再见！"));
                }
                else {
                    Response.Write(msg.ResponseWithText("您已经开始啦，继续猜吧，请猜一个1~100之间的整数"));
                }
            }
            else if (game != null && game.isWin) {
                Store.Remove(msg.FromUserName);
                Response.Write(msg.ResponseWithNews("这是一个神秘图纹", "点击打开", "http://pic6.huitu.com/res/20130116/84481_20130116142820494200_1.jpg", "www.gjn.party"));
            }else if(game != null && game.replyMessages.Count == 6 && game.isWin == false){
                Store.Remove(msg.FromUserName);
                Response.Write(msg.ResponseWithText("太失败了，给你5次机会都没猜中，再见！"));
            }
            else if (msg.Content == "玩游戏")
            {
                Random r = new Random();
                int i = r.Next(100);
                game = new GameItem(i);
                game.userMessages.Add(msg.Content);
                game.replyMessages.Add("欢迎开始猜数字游戏，请猜一个1~100之间的整数");
                if (Store.ContainsKey(msg.FromUserName))
                {
                    Store[msg.FromUserName] = game;
                }
                else
                {
                    Store.Add(msg.FromUserName, game);
                    
                }
                //game.replyMessages.Add("欢迎开始猜数字游戏，请猜一个1~100之间的整数");
                Response.Write(msg.ResponseWithText("欢迎开始猜数字游戏，请猜一个1~100之间的整数"));
            }
            else {
                //game.replyMessages.Add("要玩游戏的话，请回复‘玩游戏’");
                Response.Write(msg.ResponseWithText("要玩游戏的话，请回复‘玩游戏"));
            }

            
        }
        
    }

    protected void verifySignature()
    {
        string token = "UPFVef6NSjD3nJ6NennzdpDnvlSpZPq3";

        string signature = Request["signature"];
        string timestamp = Request["timestamp"];
        string nonce = Request["nonce"];
        string echostr = Request["echostr"];

        ArrayList AL = new ArrayList();
        AL.Add(token);
        AL.Add(timestamp);
        AL.Add(nonce);
        AL.Sort(new DictionarySort());

        string raw = "";
        for (int i = 0; i < AL.Count; i++)
        {
            raw += AL[i].ToString();
        }

        SHA1 sha;
        ASCIIEncoding enc;
        string hash = "";
        try
        {
            sha = new SHA1CryptoServiceProvider();
            enc = new ASCIIEncoding();
            byte[] dataToHash = enc.GetBytes(raw);
            byte[] dataHashed = sha.ComputeHash(dataToHash);
            hash = BitConverter.ToString(dataHashed).Replace("-", "");
            hash = hash.ToLower();
        }
        catch (Exception)
        {
            Response.Write("加密出错啦");
        }

        if (hash == signature)
        {
            Response.Write(echostr);
        }
        else
        {
            Response.Write("fail");
        }
    }

    public class GameItem
    {
        public int answer;
        public bool isWin;

        public List<string> userMessages;
        public List<string> replyMessages;

        public GameItem(int num)
        {
            this.answer = num;
            this.isWin = false;
            this.userMessages = new List<string>();
            this.replyMessages = new List<string>();
        }
    }
}

public class DictionarySort : System.Collections.IComparer
{
    public int Compare(object oLeft, object oRight)
    {
        string sLeft = oLeft as string;
        string sRight = oRight as string;
        int iLeftLength = sLeft.Length;
        int iRightLength = sRight.Length;
        int index = 0;
        while (index < iLeftLength && index < iRightLength)
        {
            if (sLeft[index] < sRight[index])
                return -1;
            else if (sLeft[index] > sRight[index])
                return 1;
            else
                index++;
        }
        return iLeftLength - iRightLength;
    }
}

/// <summary>
/// 当普通微信用户向公众账号发消息时，微信服务器将POST消息的XML数据包到开发者填写的URL上
/// </summary>
public class WXUserMessage
{
    /// <summary>
    /// 构造函数
    /// </summary>
    public WXUserMessage() { }

    /// <summary>
    /// 开发者微信号
    /// </summary>
    public string ToUserName;

    /// <summary>
    /// 发送方帐号（一个OpenID）
    /// </summary>
    public string FromUserName;

    /// <summary>
    /// text,image,voice,video,location,link, event
    /// </summary>
    public string MsgType;

    /// <summary>
    /// 消息id，64位整型
    /// </summary>
    public Int64 MsgId;

    /// <summary>
    /// 消息创建时间 （整型）
    /// </summary>
    public int CreateTime;

    /// <summary>
    /// 文本消息内容
    /// </summary>
    public string Content;

    /// <summary>
    /// 接收并转化用户消息为内置对象
    /// </summary>
    /// <param name="request">消息接收页面的HTTPRequest对象</param>
    /// <example><code>
    /// protected void Page_Load(object sender, EventArgs e)
    /// {
    ///    WXUserMessage umsg = WXUserMessage.GetUserMessageFromRequest(this.Request);
    ///    //你的其他操作
    ///    bool isSub = (umsg.Event == EventType.subscribe);
    /// }
    /// </code></example>
    /// <exception cref="Exception">程序级错误</exception>
    /// <seealso cref="Zeego.WeChat.MP.WXUserMessage.GetUserMessageFromRequest(string)"/>
    /// <returns>用户消息对象</returns>
    public static WXUserMessage GetUserMessageFromRequest(HttpRequest request)
    {
        if (request == null)
            return null;
        System.IO.Stream s = request.InputStream;
        byte[] b = new byte[s.Length];
        s.Read(b, 0, (int)s.Length);
        string postStr = System.Text.Encoding.UTF8.GetString(b);

        if (string.IsNullOrEmpty(postStr))
            return null;
        if (!string.IsNullOrEmpty(postStr))
        {
            return loadFromXMLString(postStr);
        }
        return new WXUserMessage();
    }

    /// <summary>
    /// 解析XML
    /// </summary>
    /// <param name="xmlData">微信服务器POST的消息XML数据包</param>
    /// <exception cref="Exception">程序级错误</exception>
    /// <returns>用户消息对象</returns>   
    private static WXUserMessage loadFromXMLString(string xmlData)
    {
        WXUserMessage uMsg = new WXUserMessage();
        XmlDocument doc = new XmlDocument();
        doc.LoadXml(xmlData);
        XmlNodeList list = doc.GetElementsByTagName("xml");
        XmlNode xn = list[0];

        uMsg.MsgType = xn.SelectSingleNode("//MsgType").InnerText;
        uMsg.ToUserName = xn.SelectSingleNode("//ToUserName").InnerText;
        uMsg.FromUserName = xn.SelectSingleNode("//FromUserName").InnerText;
        uMsg.CreateTime = Convert.ToInt32(xn.SelectSingleNode("//CreateTime").InnerText);

        switch (uMsg.MsgType)
        {
            case "text":
                uMsg.Content = xn.SelectSingleNode("//Content").InnerText;
                uMsg.MsgId = Convert.ToInt64(xn.SelectSingleNode("//MsgId").InnerText);
                break;
            default:
                break;
        }

        return uMsg;
    }

    /// <summary>
    /// 回复文本消息
    /// </summary>
    /// <param name="myContent">要回复的消息，支持换行（\n）</param>
    /// <returns>返回XML字符串</returns>
    public string ResponseWithText(string myContent)
    {
        string strresponse = "<xml>";
        strresponse += "<ToUserName><![CDATA[" + this.FromUserName + "]]></ToUserName>";
        strresponse += "<FromUserName><![CDATA[" + this.ToUserName + "]]></FromUserName>";
        strresponse += "<CreateTime>" + DateTime.Now.Ticks.ToString() + "</CreateTime>";
        strresponse += "<MsgType><![CDATA[text]]></MsgType>";
        strresponse += "<Content><![CDATA[" + myContent + "]]></Content>";
        strresponse += "</xml>";
        return strresponse;
    }

    /// <summary>
    /// 回复图文消息
    /// *多条图文消息信息，默认第一个item为大图
    /// *注意，如果图文数超过10，则将会无响应
    /// </summary>
    /// <param name="articleList">图文消息列表</param>
    /// <returns>回XML字符串</returns>
    public string ResponseWithNews(string title, string desc, string picUrl, string url)
    {
        string strresponse = "<xml>";
        strresponse += "<ToUserName><![CDATA[" + this.FromUserName + "]]></ToUserName>";
        strresponse += "<FromUserName><![CDATA[" + this.ToUserName + "]]></FromUserName>";
        strresponse += "<CreateTime>" + DateTime.Now.Ticks.ToString() + "</CreateTime>";
        strresponse += "<MsgType><![CDATA[news]]></MsgType>";
        strresponse += "<ArticleCount>1</ArticleCount>";
        strresponse += "<Articles>";

        strresponse += "<item>";
        strresponse += "<Title><![CDATA[" + title + "]]></Title>";
        strresponse += "<Description><![CDATA[" + desc + "]]></Description>";
        strresponse += "<PicUrl><![CDATA[" + picUrl + "]]></PicUrl>";
        strresponse += "<Url><![CDATA[" + url + "]]></Url>";
        strresponse += "</item>";

        strresponse += "</Articles>";
        strresponse += "</xml>";
        return strresponse;
    }
}
