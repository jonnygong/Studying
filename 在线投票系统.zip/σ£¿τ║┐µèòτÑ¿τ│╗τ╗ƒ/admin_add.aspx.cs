﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

public partial class admin_add : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["userName"] == null)
            {
                Response.Redirect("~/login.aspx");
                return;
            }
        }
    }
    protected void txt_TextChanged(object sender, EventArgs e)
    {
        //验证是否为空
        string people = txtPeople.Text.Trim();
        if (people.Equals(""))
        {
            Response.Write("<script>alert('参赛人不能为空')</script>");
            return;
        }

        string title = txtTitle.Text.Trim();
        if (title.Equals(""))
        {
            Response.Write("<script>alert('网站标题不能为空')</script>");
            return;
        }

        string url = txtUrl.Text.Trim();
        if (url.Equals(""))
        {
            Response.Write("<script>alert('网址不能为空')</script>");
            return;
        }


        //判断网址是否正确
        String check = @"((http|ftp|https)://)(([a-zA-Z0-9\._-]+\.[a-zA-Z]{2,6})|([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}))(:[0-9]{1,4})*(/[a-zA-Z0-9\&%_\./-~-]*)?";
        if (System.Text.RegularExpressions.Regex.IsMatch(txtUrl.Text, check ))
        {
            //连接数据库
            OleDbConnection conn = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + Server.MapPath("./App_Data/vote.mdb"));

            //操作数据库
            string sql = "insert into web (webname,link,maker) values ('" + title + "','" + url + "','" + people + "')";
            OleDbCommand cmd = new OleDbCommand(sql, conn);

            conn.Open();
            cmd.ExecuteNonQuery();

            conn.Close();

            txtPeople.Text = "";
            txtTitle.Text = "";
            txtUrl.Text = "";
            Response.Redirect("~/admin_add.aspx");

        }
        else
        {
            Response.Write("<script>alert('网站url格式错误！')</script>");
        }

        
    }
    protected void btnRefill_Click(object sender, EventArgs e)
    {
        txtPeople.Text = "";
        txtTitle.Text = "";
        txtUrl.Text = "";
    }
}
