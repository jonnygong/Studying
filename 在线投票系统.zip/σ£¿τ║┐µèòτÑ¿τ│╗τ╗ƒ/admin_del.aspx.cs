﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

public partial class admin_del : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["userName"] == null)
            {
                Response.Redirect("~/login.aspx");
                return;
            }
        }
        
    }

    

    protected void btnDel_Click(object sender, EventArgs e)
    {
        int ddlPeople = int.Parse(ddlPeoAndPro.SelectedValue);
        

        //连接数据库
        OleDbConnection conn = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + Server.MapPath("./App_Data/vote.mdb"));

        //操作数据库
        string sql = "delete * from web where id=" + ddlPeople + "";
        OleDbCommand cmd = new OleDbCommand(sql, conn);

        conn.Open();
        cmd.ExecuteNonQuery();

        conn.Close();

        Response.Redirect("~/admin_del.aspx");
    }
    protected void ddlPeoAndPro_SelectedIndexChanged(object sender, EventArgs e)
    {
        //OleDbConnection conn = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + Server.MapPath("./App_Data/vote.mdb"));
        //OleDbDataAdapter da = new OleDbDataAdapter("select maker,webname from web", conn);
        //DataSet ds = new DataSet();
        //da.Fill(ds);

        //string str = "<asp:ListItem></asp:ListItem>";
        //string maker = ds.Tables[0].Rows[0]+"";
        //string webname = ds.Tables[0].Rows[1]+"";
        //$("#ddlPeoAndPro").html(maker+webname);
        //str+="";
    }
}
