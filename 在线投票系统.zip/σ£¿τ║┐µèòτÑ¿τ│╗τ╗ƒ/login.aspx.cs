﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

public partial class login : System.Web.UI.Page
{
    Random r = new Random();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack) {
            int a = r.Next(1000, 10000);
            Label1.Text = a + "";
        }
    }
    protected void Button1_ServerClick(object sender, EventArgs e)
    {
        //验证
        string name = txtName.Value.Trim();
        if(name.Equals("")){
            Response.Write("<script>alert('用户名不能为空')</script>");
            int a = r.Next(1000, 10000);
            Label1.Text = a + "";
            return;
        }

        string pwd = txtPwd.Value.Trim();
        if (pwd.Equals("")) {
            Response.Write("<script>alert('密码不能为空')</script>");
            int a = r.Next(1000, 10000);
            Label1.Text = a + "";
            return;
        }
        string veriCode = txtYz.Value.Trim();
        string veriCode2 = Label1.Text;
        if (veriCode.Equals(""))
        {
            Response.Write("<script>alert('验证码不能为空')</script>");
            int a = r.Next(1000, 10000);
            Label1.Text = a + "";
            return;
        }
        if (!veriCode.Equals(veriCode2))
        {
            Context.Response.Write("<script>alert('验证码错误')</script>");
            int a = r.Next(1000, 10000);
            Label1.Text = a + "";
            return;
        }




        //连接数据库
            OleDbConnection conn = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + Server.MapPath("./App_Data/vote.mdb"));
            OleDbDataAdapter da = new OleDbDataAdapter("select * from admin where adminname='"+name+"' and password='"+pwd+"' ", conn);
            DataSet ds = new DataSet();
            da.Fill(ds);

            name = name.Replace("'", "''");
            name = name.Replace("--", "");
            pwd = pwd.Replace("'", "''");

            int cnt = ds.Tables[0].Rows.Count;
            if(cnt==0){
                Context.Response.Write("<script>alert('用户名或密码输入错误')</script>");
                txtName.Focus();
                int a = r.Next(1000, 10000);
                Label1.Text = a + "";
                return;
            }
            if (cnt != 0)
            {
                Context.Response.Write("<script>alert('输入正确')</script>");
            }


        //成功的登录
            Session["userId"] = ds.Tables[0].Rows[0]["id"];
            Session["userName"] = name;
            Session["userPwd"] = pwd;
            string opt = RadioButtonList1.SelectedItem.Value;
            switch (opt) { 
                case "1":
                    Response.Redirect("~/admin_changepwd.aspx"); break;
                case "2":
                    Response.Redirect("~/admin_add.aspx"); break;
                case "3":
                    Response.Redirect("~/admin_del.aspx"); break;
            }

    }

}
