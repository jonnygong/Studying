﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

public partial class vote : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_ServerClick(object sender, EventArgs e)
    {
        //获取数据
        string pname = txtname.Value;
        string pno = txtpno.Value;
        string page1 = txtpage1.Value;
        string sex = RadioButtonList1.SelectedItem.Text;
        string pdep = txtpdep.Value;
        string pclass = txtpclass.Value;
        string dno = txtpdno.Value;
        string pemil = txtpemail.Value;
        string dropolis = DropDownList1.SelectedItem.Value;
        string preason = txtpreason.Value;

        //连接数据库
        OleDbConnection conn = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + Server.MapPath("./App_Data/vote.mdb"));
       
        //操作数据库
        //对voteList
        string sql1 = "insert into voteList(votername,sno,age,sex,department,class,idcard,email,webid,reason)"+"values ('"+pname+"','"+pno+"',"+page1+",'"+sex+"','"+pdep+"','"+pclass+"','"+dno+"','"+pemil+"','"+dropolis+"','"+preason+"')";
        string sql2 = "update web set getvotes=getvotes+1 where id="+dropolis;
        OleDbCommand cmd = new OleDbCommand(sql1,conn);
        OleDbCommand cmd2 = new OleDbCommand(sql2,conn);
        conn.Open();
        cmd.ExecuteNonQuery();
        cmd2.ExecuteNonQuery();
        conn.Close();
        //清空
        Button2_ServerClick(sender,e);

    }
    protected void Button2_ServerClick(object sender, EventArgs e)
    {
        txtname.Value = "";
        txtpno.Value = "";
        txtpage1.Value = "";
        RadioButtonList1.SelectedItem.Text="";
        txtpdep.Value = "";
        txtpclass.Value = "";
        txtpdno.Value = "";
        txtpemail.Value = "";
        DropDownList1.SelectedItem.Value = "";
        txtpreason.Value="";
    }
}
