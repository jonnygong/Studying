﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

public partial class admin_changepwd : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            if (Session["userName"] == null) {
                Response.Redirect("~/login.aspx");
                return;
            }
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //验证是否为空
        string olePwd = txtOldPwd.Text.Trim();
        if (olePwd.Equals(""))
        {
            Response.Write("<script>alert('旧密码不能为空')</script>");
            return;
        }

        string newPwd = txtNewPwd.Text.Trim();
        if (newPwd.Equals(""))
        {
            Response.Write("<script>alert('新密码不能为空')</script>");
            return;
        }

        string reNewPwd = txtReNewPwd.Text.Trim();
        if (reNewPwd.Equals(""))
        {
            Response.Write("<script>alert('确认新密码不能为空')</script>");
            return;
        }


        //验证新密码是否相同
        if (!newPwd.Equals(reNewPwd))
        {
            Context.Response.Write("<script>alert('两次输入不相同')</script>");
            return;
        }

        //验证旧密码是否输入正确
        OleDbConnection conn = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + Server.MapPath("./App_Data/vote.mdb"));
        OleDbDataAdapter da = new OleDbDataAdapter("select * from admin where password='" + olePwd + "' ", conn);
        DataSet ds = new DataSet();
        da.Fill(ds);

        int cnt = ds.Tables[0].Rows.Count;
        if (cnt == 0)
        {
            Context.Response.Write("<script>alert('旧密码输入错误')</script>");
            txtOldPwd.Focus();
            return;
        }
        //if (cnt != 0)
        //{
        //    Context.Response.Write("<script>alert('旧密码输入正确')</script>");
        //}

        //输入新密码

        //连接数据库
        OleDbConnection conn2 = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + Server.MapPath("./App_Data/vote.mdb"));
        
        //操作数据库
        string sql = "update admin set [password]='" + newPwd + "' where adminname='" + Session["userName"]+"'";
        OleDbCommand cmd = new OleDbCommand(sql, conn2);
        
        conn2.Open();
        cmd.ExecuteNonQuery();
        
        conn2.Close();
    }
}
