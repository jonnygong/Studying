﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

public partial class index : System.Web.UI.Page 
{
    public string voteresult = "";
    protected void Page_Load(object sender, EventArgs e)
    {
       
        if(!IsPostBack)
        {
            OleDbConnection conn = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source="+Server.MapPath("./App_Data/vote.mdb"));
            OleDbDataAdapter da = new OleDbDataAdapter("select * from web",conn);
            DataSet ds = new DataSet();
            da.Fill(ds);
          
            //GridView1.DataSource = ds.Tables[0].DefaultView;
            //GridView1.DataBind();
            int rowCnt = ds.Tables[0].Rows.Count;
            int sumVote = 0;
            for (int i = 0; i < rowCnt;i++ )
            {
                int vote = int.Parse(ds.Tables[0].Rows[i]["getvotes"].ToString());
                sumVote += vote;
            }
            //
            for (int i = 0; i < rowCnt;i++ ) {
                string webName = ds.Tables[0].Rows[i]["webname"].ToString();
                string maker = ds.Tables[0].Rows[i]["maker"].ToString();
                int vote = int.Parse(ds.Tables[0].Rows[i]["getvotes"].ToString());
                int width=vote*200/sumVote;
                voteresult += "<div><p><span style=\"float: left;width:210px;\">网站：" + webName + " 名字：" + maker + "</span></p><div class=\"jindu\"><div style=\"width:" + width + "px; height:13px; background:url(images/jindu.png)\"></div></div><p><span style=\"float:right;margin-right:20px;\">" + vote + "票</span></p><p> &nbsp;</p> </div>";
                                
                            
                               
                            
                       
            
            }
                
        }
    }
}
