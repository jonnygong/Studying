$(document).ready(function(){
  $(".question > h2").on("click", function (e) {
      $(this).next().next().slideToggle("slow");
  });

  $(function () { $("[data-toggle='tooltip']").tooltip(); });

  $("#calendar").bootstrapDatepickr();
  $("#calendar1").bootstrapDatepickr();
  $("#calendar2").bootstrapDatepickr();

  $('.sel-a').click(function(){
    $('.m-class').attr('value',$(this).html());
  });
})







var countdown=60;
function settime(obj) {
    if (countdown == 0) {
        obj.removeAttribute("disabled");
        obj.value="免费获取验证码";
        countdown = 60;
        return;
    } else {
        obj.setAttribute("disabled", true);
        obj.value="重新发送(" + countdown + ")";
        countdown--;
    }
setTimeout(function() {
    settime(obj) }
    ,1000)

}
