





//验证姓名
function checkna(){
  var e = window.event || event;
  var value = e.target.value;
  if(value='' || validate_na(value)) {
    e.target.nextElementSibling.innerHTML= '<font class="tips_false">长度是4~8个字符</font>';
  }else{
    e.target.nextElementSibling.innerHTML= '<font class="tips_true">输入正确</font>';
  }
}

function validate_na(str) {
  if( str.length <4 || str.length >8)
    {
      return true;
    }else{
      return false;
    }
}




//验证手机号
function checkphone(){
  var e = window.event || event;
  var value = e.target.value;
  if(value=='' || !validate_phone(value)) {
    e.target.nextElementSibling.innerHTML= '<font class="tips_false">请输入正确的手机号</font>';
  }else{
    e.target.nextElementSibling.innerHTML= '<font class="tips_true">输入正确</font>';
  }

}

function validate_phone(str) {
  if(str.search(/^(\+\d{2,3})?\d{11}$/) === -1)
      return false;
    else
      return true;
  }




//验证邮箱
function checkmail(){
  var e = window.event || event;
  var value = e.target.value;
  if(value='' || validate_mail(value)) {
    e.target.nextElementSibling.innerHTML= '<font class="tips_false">请输入正确的邮箱</font>';
  }else{
    e.target.nextElementSibling.innerHTML= '<font class="tips_true">输入正确</font>';
  }

}

function validate_mail(str) {

  apos=str.indexOf("@");
        dotpos=str.lastIndexOf(".");
        if (apos<1||dotpos-apos<2)
          {
            return true;
          }
        else {
          return false;
}
}


//验证密码

function checkpwd(){
  var e = window.event || event;
  var value = e.target.value;
  var reg = /^[0-9a-zA-Z]+$/;
  if(password.length<6 || !reg.test(str)){
    e.target.nextElementSibling.innerHTML= '<font class="tips_false">密码至少大于等于6位</font>';



}else{
  e.target.nextElementSibling.innerHTML= '<font class="tips_true">密码输入正确</font>';
}


}














//验证学号
function validate_no(){
  var checkno = document.getElementById('checkno');
  var e = window.event || event;
  var value = e.target.value;
    var text1 = document.getElementById("checkno").value;
    var len = 10 - text1.length;
    var show = "你还可以输入" + len + "个字";
    document.getElementById("divnumber").innerText = show;
    if (typeof text1 == "string")
    {

      if (text1.substring(0, 4) == "2015")
      {
        if (text1.length != 10)
         {
          e.target.nextElementSibling.innerHTML= '<font class="tips_false">学号必须为10位</font>';
         }
         else
         {
          e.target.nextElementSibling.innerHTML= '<font class="tips_true">输入正确</font>';
         }
      }
      else
      {
        e.target.nextElementSibling.innerHTML= '<font class="tips_false">前四位必须是2015</font>';
      }
    }
    else
    {
      e.target.nextElementSibling.innerHTML= '<font class="tips_false">必须为数字</font>';
    }

}



//验证账号
function validate_acc(){
  var checkacc = document.getElementById('checkacc');
  var e = window.event || event;
  var value = e.target.value;
    var text2 = document.getElementById("checkacc").value;
    var reg = /^[a-zA-Z]{1,26}$/;
    if (reg.test(text2))
    {
      if (text2.length<3)
      {
        e.target.nextElementSibling.innerHTML= '<font class="tips_false">不得少于3位</font>';
      }
      else
      {
        e.target.nextElementSibling.innerHTML= '<font class="tips_true">输入正确</font>';
      }
    } else
    {
      e.target.nextElementSibling.innerHTML= '<font class="tips_false">必须为英文</font>';
    }
}

//验证密码
function validate_pwd(){
  var checkpwd=document.getElementById("checkpwd");
  var e = window.event || event;
  var value = e.target.value;
    var text3=document.getElementById("checkpwd").value;
    var containSpecial = RegExp(/[(\ )(\~)(\!)(\@)(\#) (\$)(\%)(\^)(\&)(\*)(\()(\))(\-)(\_)(\+)(\=) (\[)(\])(\{)(\})(\|)(\\)(\;)(\:)(\')(\")(\,)(\.)(\/) (\<)(\>)(\ )(\)]+/);
    if (!containSpecial.test(text3))
     {
              if (text3.length>6)
              {
                 if (text3.length<16)
                 {
                     e.target.nextElementSibling.innerHTML= '<font class="tips_true">输入正确</font>';
                 }
                 else
                 {
                     e.target.nextElementSibling.innerHTML= '<font class="tips_false">密码不能超过16位</font>';
                 }
              }
              else
              {
                e.target.nextElementSibling.innerHTML= '<font class="tips_false">密码不能少于6位</font>';
              }
     }
     else
     {
              e.target.nextElementSibling.innerHTML= '<font class="tips_false">请不要使用特殊字符</font>';
     }


}
