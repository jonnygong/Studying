﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace _00层
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }
        bool playing = false;
        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(!playing)
            {
                return;
            }
            if (e.KeyChar == 'a')
            {
                picMan.Left -= 15;
                if (picMan.Left <= 0)
                {
                    picMan.Left = 0;
                }
            }
            if (e.KeyChar == 'd')
            {
                picMan.Left += 15;
                if (picMan.Left >= panel1.Width - picMan.Width)
                {
                    picMan.Left = panel1.Width - picMan.Width;
                }
            }
            
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            playing = true;
        }
        int score = 0;
        int delay = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            picMan.Top += 10;
            score++;
            lblScore.Text = "得分："+score.ToString();
            BoardRaise();
            if (picMan.Top <= 0 || picMan.Top >= panel1.Height)
            {
                timer1.Enabled = false;
                MessageBox.Show("you boomshakalaka！");
            }
        }

        private void BoardRaise()
        {
            delay++;
            picSpring.Top -= 10;
            if (delay > 12)
            {
                picSlide.Top -= 18;
            }
            if (delay > 22)
            {
                picBrick.Top -= 5;
            }
            if (delay > 32)
            {
                picNail.Top -= 8;
            }
            
        }

        private void InitGame()
        {
            score = 0;
            lblScore.Text = score.ToString();
            delay = 0;
            picMan.Top = this.Height/3;
            picMan.Left = this.Width / 2;
            picNail.Top = panel1.Height + 15;
            picSlide.Top = panel1.Height + 15;
            picSpring.Top = panel1.Height + 15;
            picBrick.Top = panel1.Height + 15;
            
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            playing = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            InitGame();
            BoardBack();
        }
        private void BoardBack()
        {
            if (picBrick.Bottom < 0)
            {
                picBrick.Top = panel1.Height + 15;
            }
            if (picNail.Bottom < 0)
            {
                picNail.Top = panel1.Height + 15;
            }
            if (picSlide.Bottom < 0)
            {
                picSlide.Top = panel1.Height + 15;
            }
            if (picSpring.Bottom < 0)
            {
                picSpring.Top = panel1.Height + 15;
            }
            
                                                                                    
        }
        private void ManFollow(PictureBox picB)
        {
            if ((picMan.Left>=picB.Left&&picMan.Left<=picB.Right||
                picMan.Right>=picB.Left&& picMan.Right<=picB.Right)
                picMan.Bottom>=picB.Top&&picMan.Bottom<=picB.Bottom)
            {
                picMan.Top = picB.Height-picMan.Top;
            }
        }
    }
   

}