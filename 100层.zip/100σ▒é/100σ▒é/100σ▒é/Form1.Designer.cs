﻿namespace _00层
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnStart = new System.Windows.Forms.Button();
            this.btnStop = new System.Windows.Forms.Button();
            this.lblScore = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.picMan = new System.Windows.Forms.PictureBox();
            this.picNail = new System.Windows.Forms.PictureBox();
            this.picBrick = new System.Windows.Forms.PictureBox();
            this.picSlide = new System.Windows.Forms.PictureBox();
            this.picSpring = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picMan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBrick)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSlide)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSpring)).BeginInit();
            this.SuspendLayout();
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(408, 155);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(75, 23);
            this.btnStart.TabIndex = 0;
            this.btnStart.Text = "开始";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnStop
            // 
            this.btnStop.Location = new System.Drawing.Point(408, 230);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(75, 23);
            this.btnStop.TabIndex = 1;
            this.btnStop.Text = "暂停";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // lblScore
            // 
            this.lblScore.AutoSize = true;
            this.lblScore.Location = new System.Drawing.Point(417, 57);
            this.lblScore.Name = "lblScore";
            this.lblScore.Size = new System.Drawing.Size(35, 12);
            this.lblScore.TabIndex = 2;
            this.lblScore.Text = "得分:";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.picMan);
            this.panel1.Controls.Add(this.picNail);
            this.panel1.Controls.Add(this.picBrick);
            this.panel1.Controls.Add(this.picSlide);
            this.panel1.Controls.Add(this.picSpring);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(402, 454);
            this.panel1.TabIndex = 3;
            // 
            // picMan
            // 
            this.picMan.Image = ((System.Drawing.Image)(resources.GetObject("picMan.Image")));
            this.picMan.Location = new System.Drawing.Point(100, 100);
            this.picMan.Name = "picMan";
            this.picMan.Size = new System.Drawing.Size(33, 44);
            this.picMan.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picMan.TabIndex = 8;
            this.picMan.TabStop = false;
            // 
            // picNail
            // 
            this.picNail.Image = ((System.Drawing.Image)(resources.GetObject("picNail.Image")));
            this.picNail.Location = new System.Drawing.Point(280, 387);
            this.picNail.Name = "picNail";
            this.picNail.Size = new System.Drawing.Size(122, 15);
            this.picNail.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picNail.TabIndex = 7;
            this.picNail.TabStop = false;
            // 
            // picBrick
            // 
            this.picBrick.Image = ((System.Drawing.Image)(resources.GetObject("picBrick.Image")));
            this.picBrick.Location = new System.Drawing.Point(79, 387);
            this.picBrick.Name = "picBrick";
            this.picBrick.Size = new System.Drawing.Size(142, 25);
            this.picBrick.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picBrick.TabIndex = 6;
            this.picBrick.TabStop = false;
            // 
            // picSlide
            // 
            this.picSlide.Image = ((System.Drawing.Image)(resources.GetObject("picSlide.Image")));
            this.picSlide.Location = new System.Drawing.Point(189, 387);
            this.picSlide.Name = "picSlide";
            this.picSlide.Size = new System.Drawing.Size(127, 22);
            this.picSlide.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picSlide.TabIndex = 5;
            this.picSlide.TabStop = false;
            this.picSlide.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // picSpring
            // 
            this.picSpring.Image = ((System.Drawing.Image)(resources.GetObject("picSpring.Image")));
            this.picSpring.Location = new System.Drawing.Point(0, 387);
            this.picSpring.Name = "picSpring";
            this.picSpring.Size = new System.Drawing.Size(122, 20);
            this.picSpring.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picSpring.TabIndex = 4;
            this.picSpring.TabStop = false;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(510, 454);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lblScore);
            this.Controls.Add(this.btnStop);
            this.Controls.Add(this.btnStart);
            this.KeyPreview = true;
            this.Name = "Form1";
            this.Text = "28ManDown";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picMan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBrick)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSlide)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSpring)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Label lblScore;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox picSlide;
        private System.Windows.Forms.PictureBox picSpring;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox picMan;
        private System.Windows.Forms.PictureBox picNail;
        private System.Windows.Forms.PictureBox picBrick;
    }
}

